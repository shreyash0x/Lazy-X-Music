# PrimeMusic-Lavalink
LAVALINK BOT MADE BY SHIVA.

Fork the Repositry and add your bot token. Must turn on intents and run the code.
Use /play to start playing the songs.

# ENV
TOKEN 
 
# Config.js
Add mongoUri & spotify details

# Supports
- YouTube
- SoundCloud
- Spotify

Links / Text / Playlists
 
English (en),
Spanish (es),
French (fr),
German (de),
Chinese (Simplified) (cn),
Japanese (ja),
Korean (ko),
Russian (ru),
Portuguese (pt),
Arabic (ar),
Vietnamese (vi)
